#!/bin/bash

# Start RabbitMQ server
rabbitmq-server &

# Wait for RabbitMQ server to start
sleep 10

# Create default vhost and set permissions
rabbitmqctl add_vhost /
rabbitmqctl set_permissions -p / admin ".*" ".*" ".*"

# Keep the container running
tail -f /dev/null


# login in docker => docker exec -it rabbitmq bash
# active plugin rabbitmq_delayed_message_exchange => rabbitmq-plugins enable rabbitmq_delayed_message_exchange
# result message :
# Enabling plugins on node rabbit@<hostname>:
# rabbitmq_delayed_message_exchange

# if not found download last version in address https://github.com/rabbitmq/rabbitmq-delayed-message-exchange/releases/
# copy to docker => docker cp rabbitmq_delayed_message_exchange-4.0.2.ez rabbitmq:/plugins/
# enable plugin => rabbitmq-plugins enable rabbitmq_delayed_message_exchange

# restart plugin => rabbitmqctl stop
# => rabbitmq-server -detached

